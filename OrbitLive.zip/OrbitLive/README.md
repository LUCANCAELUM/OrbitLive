# Orbit Live — every TV channel & radio station, one app

Native Android (Kotlin · Jetpack Compose · Media3/ExoPlayer).

**Data sources (all free, public, no API keys)**
- TV: [iptv-org](https://iptv-org.github.io/) API (`channels`, `streams`, `logos`, `countries`) – the same dataset behind TV Garden
- Radio: community [radio-browser.info](https://www.radio-browser.info/) mirrors

## Build the APK on GitHub (no local setup)
1. Create a new GitHub repo and upload the **contents** of this folder (keep `.github/` at the repo root).
2. Open the **Actions** tab → *Build APK* runs automatically on push (or click *Run workflow*).
3. When it finishes, download the **OrbitLive-APKs** artifact → `app-debug.apk` / `app-release.apk` → install on your phone.

## Features
- Live TV by country & genre, instant search, thousands of channels
- Radio by country & genre with animated equalizer
- **Zap mode**: swipe up/down in the player to change channels like a TV remote
- **Auto-failover**: if a stream dies, the next source for that channel loads automatically
- **Auto-surf**: hops to a new channel every 25 s · **Surprise me** random pick
- Picture-in-Picture, background audio + lock-screen controls, sleep timer
- Favorites & recents (stored on-device)

## Built for huge traffic
There is no backend to overload: catalogue JSON comes from static CDNs (cached on-device 6 h, offline fallback),
video/audio streams come straight from broadcasters, radio calls are load-balanced across mirrors client-side,
logos use disk+memory caching, and lists are lazily rendered.
