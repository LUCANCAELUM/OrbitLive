package com.orbit.live

import android.app.Activity
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

@Composable
fun Equalizer(active: Boolean) {
    val t = rememberInfiniteTransition(label = "eq")
    Row(Modifier.height(70.dp), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.Bottom) {
        repeat(16) { i ->
            val h by t.animateFloat(0.15f, 1f, infiniteRepeatable(tween(380 + i * 47, easing = LinearEasing), RepeatMode.Reverse), label = "b$i")
            Box(
                Modifier.width(6.dp).fillMaxHeight(if (active) h else 0.12f).clip(RoundedCornerShape(3.dp))
                    .background(Brush.verticalGradient(listOf(Cyan, Violet)))
            )
        }
    }
}

@Composable
fun PlayerScreen(vm: AppVM) {
    val s = vm.current ?: return
    val act = LocalContext.current as Activity
    val view = LocalView.current
    var controls by remember { mutableStateOf(true) }
    var drag by remember { mutableFloatStateOf(0f) }
    var menu by remember { mutableStateOf(false) }

    LaunchedEffect(s.id) { controls = true }
    LaunchedEffect(controls, vm.isPlaying, menu) { if (controls && vm.isPlaying && !menu) { delay(3500); controls = false } }
    DisposableEffect(Unit) {
        val c = WindowCompat.getInsetsController(act.window, view)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
        onDispose {
            c.show(WindowInsetsCompat.Type.systemBars())
            act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .pointerInput(Unit) { detectTapGestures { controls = !controls } }
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { drag = 0f },
                    onDragEnd = { if (drag < -180) vm.zap(1) else if (drag > 180) vm.zap(-1); drag = 0f },
                    onVerticalDrag = { _, d -> drag += d }
                )
            }
    ) {
        if (!s.radio) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        useController = false
                        resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                        setShutterBackgroundColor(android.graphics.Color.BLACK)
                        player = vm.player
                    }
                },
                update = { it.player = vm.player },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color(0xFF3B1F8F), Color(0xFF0B0820)))), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(180.dp).clip(RoundedCornerShape(36.dp)).background(Color(0xFFEDEBFA)), Alignment.Center) {
                        if (s.logo != null) AsyncImage(s.logo, null, Modifier.fillMaxSize().padding(20.dp), contentScale = ContentScale.Fit)
                        else Icon(Icons.Rounded.Radio, null, Modifier.size(80.dp), tint = Violet)
                    }
                    Spacer(Modifier.height(32.dp))
                    Equalizer(vm.isPlaying)
                }
            }
        }

        if (!vm.inPip) {
            // status overlay
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                when (vm.status) {
                    Status.Loading -> CircularProgressIndicator(color = Cyan)
                    Status.Error -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("This stream is offline", fontWeight = FontWeight.Bold)
                        Text("Swipe up for the next channel", fontSize = 12.sp, color = Color(0x99FFFFFF))
                        Spacer(Modifier.height(10.dp))
                        Button({ vm.togglePlay() }) { Text("Retry") }
                    }
                    else -> {}
                }
            }

            AnimatedVisibility(controls, enter = fadeIn(), exit = fadeOut()) {
                Box(Modifier.fillMaxSize()) {
                    // top bar
                    Row(
                        Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent)))
                            .safeDrawingPadding().padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton({ vm.showPlayer = false }) { Icon(Icons.Rounded.KeyboardArrowDown, null, Modifier.size(32.dp)) }
                        Column(Modifier.weight(1f)) {
                            Text(s.name, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            val c = vm.countries[s.country]
                            Text(
                                listOfNotNull(c?.let { "${it.flag} ${it.name}" }, "Source ${vm.streamIdx + 1}/${s.urls.size}",
                                    if (vm.sleepMinutes > 0) "😴 ${vm.sleepMinutes}m" else null).joinToString(" · "),
                                fontSize = 12.sp, color = Color(0xBBFFFFFF), maxLines = 1
                            )
                        }
                        val fav = vm.isFav(s.id)
                        IconButton({ vm.toggleFav(s) }) { Icon(if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null, tint = if (fav) Pink else Color.White) }
                        if (!s.radio) {
                            IconButton({ (act as? MainActivity)?.enterPip() }) { Icon(Icons.Rounded.PictureInPictureAlt, null) }
                            IconButton({
                                act.requestedOrientation = if (landscape) ActivityInfo.SCREEN_ORIENTATION_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                            }) { Icon(Icons.Rounded.ScreenRotation, null) }
                        }
                        Box {
                            IconButton({ menu = true }) { Icon(Icons.Rounded.Bedtime, null, tint = if (vm.sleepMinutes > 0) Cyan else Color.White) }
                            DropdownMenu(menu, { menu = false }) {
                                listOf(0, 15, 30, 60, 90).forEach { m ->
                                    DropdownMenuItem(text = { Text(if (m == 0) "Sleep timer off" else "Sleep in $m min") }, onClick = { vm.setSleep(m); menu = false })
                                }
                            }
                        }
                    }
                    // bottom bar
                    Column(
                        Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                            .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xDD000000))))
                            .safeDrawingPadding().padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            RoundBtn(Icons.Rounded.SkipPrevious, 52.dp) { vm.zap(-1) }
                            RoundBtn(if (vm.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, 72.dp, true) { vm.togglePlay() }
                            RoundBtn(Icons.Rounded.SkipNext, 52.dp) { vm.zap(1) }
                        }
                        Spacer(Modifier.height(14.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            PillBtn("Auto-surf", Icons.Rounded.Autorenew, vm.surf) { vm.toggleSurf() }
                            if (s.urls.size > 1) PillBtn("Next source", Icons.Rounded.SwapHoriz, false) { vm.nextSource() }
                            PillBtn("Surprise", Icons.Rounded.Shuffle, false) { vm.surprise() }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("Swipe up / down to zap channels", fontSize = 11.sp, color = Color(0x88FFFFFF), textAlign = TextAlign.Center)
                    }
                }
            }
        }
    }
}

@Composable
private fun RoundBtn(icon: androidx.compose.ui.graphics.vector.ImageVector, size: Dp, primary: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier.size(size).clip(CircleShape)
            .background(if (primary) Brush.linearGradient(listOf(Violet, Pink)) else Brush.linearGradient(listOf(Color(0x44FFFFFF), Color(0x22FFFFFF))))
            .clickable(onClick = onClick), Alignment.Center
    ) { Icon(icon, null, Modifier.size(size * 0.55f)) }
}

@Composable
private fun PillBtn(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, active: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.clip(RoundedCornerShape(50))
            .background(if (active) Brush.horizontalGradient(listOf(Cyan, Violet)) else Brush.horizontalGradient(listOf(Color(0x33FFFFFF), Color(0x33FFFFFF))))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) { Icon(icon, null, Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text(label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
}
