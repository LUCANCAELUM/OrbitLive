package com.orbit.live

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import coil.compose.AsyncImage

private val glass = Brush.linearGradient(listOf(Color(0x33FFFFFF), Color(0x0FFFFFFF)))
private val brand = Brush.horizontalGradient(listOf(Cyan, Violet, Pink))
private val categories = listOf(
    "news", "sports", "movies", "music", "kids", "entertainment", "documentary", "general", "comedy", "series",
    "science", "education", "lifestyle", "cooking", "travel", "religious", "weather", "business", "culture",
    "animation", "family", "outdoor", "relax", "shop", "public", "legislative", "classic", "auto"
)
private val genres = listOf("pop", "rock", "news", "talk", "jazz", "classical", "dance", "electronic", "hip hop", "country", "latin", "chillout", "oldies", "reggae", "metal", "religion")

@Composable
fun Root(vm: AppVM) {
    BackHandler(vm.showPlayer) { vm.showPlayer = false }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF160C3A), cBg, cBg)))) {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f)) {
                when (vm.tab) {
                    0 -> TvScreen(vm)
                    1 -> RadioScreen(vm)
                    else -> LibraryScreen(vm)
                }
            }
            if (vm.current != null && !vm.showPlayer) MiniPlayer(vm)
            BottomBar(vm)
        }
        AnimatedVisibility(
            vm.showPlayer,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut()
        ) { PlayerScreen(vm) }
    }
}

// ───────────── building blocks ─────────────

@Composable
fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    val bg = if (selected) Brush.horizontalGradient(listOf(Violet, Pink))
    else Brush.horizontalGradient(listOf(Color(0x22FFFFFF), Color(0x22FFFFFF)))
    Text(
        label, color = Color.White, fontSize = 13.sp, maxLines = 1,
        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(bg).clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

@Composable
fun LiveBadge() {
    val t = rememberInfiniteTransition(label = "live")
    val a by t.animateFloat(0.3f, 1f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "a")
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(Color(0xCC000000)).padding(horizontal = 7.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(6.dp).alpha(a).clip(CircleShape).background(Pink))
        Spacer(Modifier.width(4.dp))
        Text("LIVE", fontSize = 9.sp, fontWeight = FontWeight.Black, color = Color.White)
    }
}

@Composable
fun SearchField(value: String, hint: String, onChange: (String) -> Unit) {
    TextField(
        value = value, onValueChange = onChange, singleLine = true,
        placeholder = { Text(hint, color = Color(0x99FFFFFF)) },
        leadingIcon = { Icon(Icons.Rounded.Search, null, tint = Color(0xBBFFFFFF)) },
        trailingIcon = { if (value.isNotEmpty()) IconButton({ onChange("") }) { Icon(Icons.Rounded.Close, null) } },
        shape = RoundedCornerShape(18.dp),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = Color(0x22FFFFFF), unfocusedContainerColor = Color(0x1AFFFFFF),
            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
            cursorColor = Cyan
        ),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun StationCard(vm: AppVM, s: Station, list: List<Station>) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier.clip(shape).background(glass).border(1.dp, Color(0x22FFFFFF), shape)
            .clickable { vm.play(s, list) }.padding(10.dp)
    ) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(1.6f).clip(RoundedCornerShape(14.dp)).background(Color(0xFFEDEBFA)),
            contentAlignment = Alignment.Center
        ) {
            if (s.logo != null) AsyncImage(s.logo, null, Modifier.fillMaxSize().padding(10.dp), contentScale = ContentScale.Fit)
            else Text(s.name.take(2).uppercase(), fontSize = 26.sp, fontWeight = FontWeight.Black, color = Violet)
            Box(Modifier.align(Alignment.TopStart).padding(6.dp)) { LiveBadge() }
            val fav = vm.isFav(s.id)
            Icon(
                if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null,
                tint = if (fav) Pink else Color(0xFF6B6690),
                modifier = Modifier.align(Alignment.TopEnd).padding(4.dp).size(30.dp).clip(CircleShape)
                    .clickable { vm.toggleFav(s) }.padding(5.dp)
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(s.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        val flag = vm.countries[s.country]?.flag ?: ""
        val sub = if (s.radio) listOf(flag + " " + s.country, s.categories.firstOrNull() ?: "", s.sub)
        else listOf(flag + " " + (vm.countries[s.country]?.name ?: s.country), s.categories.firstOrNull() ?: "")
        Text(sub.filter { it.isNotBlank() }.joinToString(" · "), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp, color = Color(0x99FFFFFF))
    }
}

private fun LazyGridScope.full(content: @Composable LazyGridItemScope.() -> Unit) =
    item(span = { GridItemSpan(maxLineSpan) }, content = content)

@Composable
private fun Title(text: String, sub: String) {
    Column(Modifier.padding(top = 8.dp)) {
        Text(text, style = TextStyle(brush = brand, fontSize = 32.sp, fontWeight = FontWeight.Black))
        Text(sub, fontSize = 13.sp, color = Color(0x99FFFFFF))
    }
}

@Composable
private fun ActionPill(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, active: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier.clip(RoundedCornerShape(50))
            .background(if (active) Brush.horizontalGradient(listOf(Cyan, Violet)) else glass)
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp))
        Text(label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun RecentRow(vm: AppVM) {
    if (vm.recents.isEmpty()) return
    Column {
        Text("Continue watching / listening", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(vm.recents, key = { it.id }) { s ->
                Column(Modifier.width(88.dp).clickable { vm.play(s, vm.recents) }, horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(72.dp).clip(CircleShape).background(Color(0xFFEDEBFA)).border(2.dp, Violet, CircleShape), contentAlignment = Alignment.Center) {
                        if (s.logo != null) AsyncImage(s.logo, null, Modifier.fillMaxSize().padding(10.dp), contentScale = ContentScale.Fit)
                        else Text(s.name.take(2), color = Violet, fontWeight = FontWeight.Black)
                    }
                    Text(s.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
    }
}

// ───────────── screens ─────────────

private val gridPad = PaddingValues(16.dp, 8.dp, 16.dp, 24.dp)

@Composable
fun TvScreen(vm: AppVM) {
    val byCount = remember(vm.tv) { vm.tv.groupingBy { it.country }.eachCount().entries.sortedByDescending { it.value }.map { it.key } }
    val q = vm.query.trim()
    val list = remember(vm.tv, q, vm.country, vm.category) {
        vm.tv.filter {
            (vm.country == null || it.country == vm.country) &&
                (vm.category == null || vm.category in it.categories) &&
                (q.isBlank() || it.name.contains(q, true))
        }
    }
    LazyVerticalGrid(
        GridCells.Adaptive(150.dp), Modifier.fillMaxSize().statusBarsPadding(), contentPadding = gridPad,
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        full { Title("Orbit Live", "${"%,d".format(vm.tv.size)} live TV channels · ${byCount.size} countries") }
        full { SearchField(vm.query, "Search channels…") { vm.query = it } }
        full {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionPill("Surprise me", Icons.Rounded.Shuffle) { vm.tab = 0; vm.surprise() }
                ActionPill("Auto-surf", Icons.Rounded.Autorenew, vm.surf) { vm.toggleSurf(); if (vm.surf) vm.surprise() }
            }
        }
        full {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Chip("🌍 All", vm.country == null) { vm.country = null } }
                items(byCount) { c ->
                    Chip(vm.countries[c]?.let { "${it.flag} ${it.name}" } ?: c, vm.country == c) { vm.country = c }
                }
            }
        }
        full {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Chip("All genres", vm.category == null) { vm.category = null } }
                items(categories) { c -> Chip(c.replaceFirstChar { it.uppercase() }, vm.category == c) { vm.category = c } }
            }
        }
        if (q.isBlank() && vm.country == null && vm.category == null) full { RecentRow(vm) }
        when {
            vm.loading -> full { Box(Modifier.fillMaxWidth().padding(48.dp), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = Cyan); Spacer(Modifier.height(12.dp)); Text("Tuning in to the world…")
                } } }
            vm.error != null && vm.tv.isEmpty() -> full { Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Couldn't load channels", fontWeight = FontWeight.Bold); Text(vm.error ?: "", fontSize = 12.sp, color = Color(0x99FFFFFF))
                Spacer(Modifier.height(12.dp)); Button({ vm.loadTv() }) { Text("Retry") } } }
            list.isEmpty() -> full { Text("No channels match.", Modifier.padding(32.dp), color = Color(0x99FFFFFF)) }
            else -> items(list, key = { it.id }) { StationCard(vm, it, list) }
        }
    }
}

@Composable
fun RadioScreen(vm: AppVM) {
    LaunchedEffect(vm.radioQuery, vm.radioCountry, vm.radioTag) {
        kotlinx.coroutines.delay(450); vm.loadRadio()
    }
    val cl = remember(vm.countries) { vm.countries.entries.sortedBy { it.value.name } }
    LazyVerticalGrid(
        GridCells.Adaptive(150.dp), Modifier.fillMaxSize().statusBarsPadding(), contentPadding = gridPad,
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        full { Title("Radio", "Tens of thousands of stations worldwide") }
        full { SearchField(vm.radioQuery, "Search stations…") { vm.radioQuery = it } }
        full { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { ActionPill("Surprise me", Icons.Rounded.Shuffle) { vm.tab = 1; vm.surprise() } } }
        full {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Chip("🌍 Worldwide", vm.radioCountry == null) { vm.radioCountry = null } }
                items(cl) { e -> Chip("${e.value.flag} ${e.value.name}", vm.radioCountry == e.key) { vm.radioCountry = e.key } }
            }
        }
        full {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Chip("Top", vm.radioTag == null) { vm.radioTag = null } }
                items(genres) { g -> Chip(g.replaceFirstChar { it.uppercase() }, vm.radioTag == g) { vm.radioTag = g } }
            }
        }
        when {
            vm.radioLoading && vm.radio.isEmpty() -> full { Box(Modifier.fillMaxWidth().padding(48.dp), Alignment.Center) { CircularProgressIndicator(color = Cyan) } }
            vm.radioError != null && vm.radio.isEmpty() -> full { Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Couldn't load stations"); Spacer(Modifier.height(8.dp)); Button({ vm.loadRadio() }) { Text("Retry") } } }
            else -> items(vm.radio, key = { it.id }) { StationCard(vm, it, vm.radio) }
        }
    }
}

@Composable
fun LibraryScreen(vm: AppVM) {
    LazyVerticalGrid(
        GridCells.Adaptive(150.dp), Modifier.fillMaxSize().statusBarsPadding(), contentPadding = gridPad,
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        full { Title("Favorites", "Your personal lineup") }
        if (vm.favs.isEmpty()) full { Text("Tap the ♥ on any channel or station to pin it here.", Modifier.padding(vertical = 24.dp), color = Color(0x99FFFFFF)) }
        else items(vm.favs, key = { it.id }) { StationCard(vm, it, vm.favs) }
        if (vm.recents.isNotEmpty()) {
            full { Text("Recently played", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(top = 16.dp)) }
            items(vm.recents, key = { "rc" + it.id }) { StationCard(vm, it, vm.recents) }
        }
    }
}

@Composable
fun MiniPlayer(vm: AppVM) {
    val s = vm.current ?: return
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp).clip(RoundedCornerShape(20.dp))
            .background(Color(0xFF1D1940)).border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(20.dp))
            .clickable { vm.showPlayer = true }.padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFEDEBFA)), Alignment.Center) {
            if (s.logo != null) AsyncImage(s.logo, null, Modifier.fillMaxSize().padding(5.dp), contentScale = ContentScale.Fit)
        }
        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
            Text(s.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
            Text(when (vm.status) { Status.Loading -> "Connecting…"; Status.Error -> "Offline — tap to retry"; else -> if (s.radio) "On air" else "Live" }, fontSize = 12.sp, color = Cyan)
        }
        IconButton({ vm.togglePlay() }) { Icon(if (vm.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null) }
        IconButton({ vm.stop() }) { Icon(Icons.Rounded.Close, null) }
    }
}

@Composable
fun BottomBar(vm: AppVM) {
    Row(Modifier.fillMaxWidth().background(Color(0xF2100D26)).navigationBarsPadding().padding(8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
        listOf(Triple("TV", Icons.Rounded.Tv, 0), Triple("Radio", Icons.Rounded.Radio, 1), Triple("Favorites", Icons.Rounded.Favorite, 2)).forEach { (l, ic, i) ->
            val sel = vm.tab == i
            Row(
                Modifier.clip(RoundedCornerShape(50)).background(if (sel) Brush.horizontalGradient(listOf(Violet, Pink)) else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent)))
                    .clickable { vm.tab = i }.padding(horizontal = 18.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(ic, null, Modifier.size(22.dp))
                AnimatedVisibility(sel) { Text(l, Modifier.padding(start = 8.dp), fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            }
        }
    }
}
