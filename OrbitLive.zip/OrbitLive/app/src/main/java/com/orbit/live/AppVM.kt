package com.orbit.live

import android.app.Application
import android.content.ComponentName
import android.net.Uri
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.*
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.*

enum class Status { Idle, Loading, Playing, Error }

class AppVM(app: Application) : AndroidViewModel(app) {
    private val prefs = Prefs(app)
    val player get() = PlayerHolder.player

    // ---- catalogue ----
    var tv by mutableStateOf<List<Station>>(emptyList())
    var countries by mutableStateOf<Map<String, Country>>(emptyMap())
    var loading by mutableStateOf(true)
    var error by mutableStateOf<String?>(null)

    // ---- navigation / filters ----
    var tab by mutableIntStateOf(0)
    var query by mutableStateOf("")
    var country by mutableStateOf<String?>(null)
    var category by mutableStateOf<String?>(null)
    var radio by mutableStateOf<List<Station>>(emptyList())
    var radioLoading by mutableStateOf(false)
    var radioError by mutableStateOf<String?>(null)
    var radioQuery by mutableStateOf("")
    var radioCountry by mutableStateOf<String?>(null)
    var radioTag by mutableStateOf<String?>(null)

    // ---- library ----
    var favs by mutableStateOf(prefs.favs())
    var recents by mutableStateOf(prefs.recents())

    // ---- playback ----
    var current by mutableStateOf<Station?>(null)
    var streamIdx by mutableIntStateOf(0)
    var status by mutableStateOf(Status.Idle)
    var isPlaying by mutableStateOf(false)
    var showPlayer by mutableStateOf(false)
    var inPip by mutableStateOf(false)
    var surf by mutableStateOf(false)
    var sleepMinutes by mutableIntStateOf(0)
    private var queue: List<Station> = emptyList()
    private var qIndex = 0
    private var surfJob: Job? = null
    private var sleepJob: Job? = null
    private var radioJob: Job? = null

    @Suppress("unused")
    private val controller = MediaController.Builder(
        app, SessionToken(app, ComponentName(app, PlaybackService::class.java))
    ).buildAsync()   // binds the media session service -> background playback + notification

    init {
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                when (state) {
                    Player.STATE_BUFFERING -> if (current != null) status = Status.Loading
                    Player.STATE_READY -> status = Status.Playing
                }
            }
            override fun onIsPlayingChanged(p: Boolean) { isPlaying = p }
            override fun onPlayerError(e: PlaybackException) {
                if (e.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    player.seekToDefaultPosition(); player.prepare()
                } else tryNextSource()
            }
        })
        loadTv()
        loadRadio()
    }

    fun loadTv() {
        loading = true; error = null
        viewModelScope.launch {
            try {
                val d = Repo.loadTv()
                tv = d.stations; countries = d.countries
            } catch (e: Exception) { error = e.message ?: "Network error" }
            loading = false
        }
    }

    fun loadRadio() {
        radioJob?.cancel()
        radioJob = viewModelScope.launch {
            radioLoading = true; radioError = null
            try { radio = Repo.loadRadio(radioCountry, radioTag, radioQuery.trim()) }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { radioError = e.message ?: "Network error" }
            radioLoading = false
        }
    }

    // ---- playback control ----
    fun play(s: Station, list: List<Station> = listOf(s)) {
        queue = list; qIndex = list.indexOfFirst { it.id == s.id }.coerceAtLeast(0)
        begin(s, 0); showPlayer = true
    }

    private fun begin(s: Station, idx: Int) {
        current = s; streamIdx = idx; status = Status.Loading
        addRecent(s)
        val url = s.urls.getOrNull(idx) ?: run { status = Status.Error; return }
        val seg = url.substringBefore('?').substringAfterLast('/')
        val mime = when {
            url.contains(".mpd") -> MimeTypes.APPLICATION_MPD
            url.contains("m3u8") || (!s.radio && !seg.contains('.')) -> MimeTypes.APPLICATION_M3U8
            else -> null
        }
        val meta = MediaMetadata.Builder().setTitle(s.name)
            .setArtist(countries[s.country]?.name ?: s.country)
            .setArtworkUri(s.logo?.let { Uri.parse(it) }).build()
        val item = MediaItem.Builder().setUri(url).setMimeType(mime).setMediaMetadata(meta).build()
        player.setMediaItem(item); player.prepare(); player.playWhenReady = true
    }

    private fun tryNextSource() {
        val s = current ?: return
        if (streamIdx + 1 < s.urls.size) begin(s, streamIdx + 1)   // automatic failover
        else { status = Status.Error; if (surf) zap(1) }
    }
    fun nextSource() { val s = current ?: return; begin(s, (streamIdx + 1) % s.urls.size) }

    fun zap(dir: Int) {
        if (queue.size < 2) return
        qIndex = (qIndex + dir + queue.size) % queue.size
        begin(queue[qIndex], 0)
    }
    fun togglePlay() {
        if (status == Status.Error) current?.let { begin(it, 0) }
        else if (player.isPlaying) player.pause() else player.play()
    }
    fun stop() {
        player.stop(); player.clearMediaItems()
        current = null; showPlayer = false; status = Status.Idle
    }
    fun surprise() {
        val pool = (if (tab == 1) radio else tv).ifEmpty { tv }
        if (pool.isEmpty()) return
        val l = pool.shuffled().take(300)
        play(l.first(), l)
    }
    fun toggleSurf() {
        surf = !surf; surfJob?.cancel()
        if (surf) surfJob = viewModelScope.launch {
            while (true) { delay(25_000); if (status == Status.Playing) zap(1) }
        }
    }
    fun setSleep(min: Int) {
        sleepJob?.cancel(); sleepMinutes = min
        if (min > 0) sleepJob = viewModelScope.launch {
            delay(min * 60_000L); player.pause(); sleepMinutes = 0
        }
    }

    // ---- library ----
    fun isFav(id: String) = favs.any { it.id == id }
    fun toggleFav(s: Station) {
        favs = if (isFav(s.id)) favs.filterNot { it.id == s.id } else listOf(s) + favs
        prefs.saveFavs(favs)
    }
    private fun addRecent(s: Station) {
        recents = (listOf(s) + recents.filterNot { it.id == s.id }).take(20)
        prefs.saveRecents(recents)
    }
}
